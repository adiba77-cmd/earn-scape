import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Calendar, Clock, Share2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/blog/flipping-websites-beginners-guide")({
  head: () => ({
    meta: [
      { title: "A Beginner's Guide to Flipping Small Websites for a Profit" },
      {
        name: "description",
        content:
          "Learn how to buy undervalued websites, improve them, and sell for a profit — from due diligence to valuation multiples.",
      },
      { property: "og:title", content: "A Beginner's Guide to Flipping Small Websites for a Profit" },
      {
        property: "og:description",
        content:
          "A step-by-step playbook for buying, improving, and selling small content websites for 2–4× annual earnings.",
      },
    ],
  }),
  component: BlogPost,
});

function AdSlot({ label, className = "" }: { label: string; className?: string }) {
  return (
    <div
      className={`flex items-center justify-center rounded-xl border border-dashed border-border bg-muted/40 text-xs uppercase tracking-widest text-muted-foreground ${className}`}
    >
      {label}
    </div>
  );
}

function BlogPost() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-lg">
        <div className="mx-auto flex h-16 max-w-4xl items-center justify-between px-4 sm:px-6">
          <Link to="/" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Back to PassiveHub
          </Link>
          <Button size="sm" variant="outline" className="gap-2">
            <Share2 className="h-4 w-4" /> Share
          </Button>
        </div>
      </header>

      <article className="mx-auto max-w-3xl px-4 py-12 sm:px-6 sm:py-16">
        <Badge variant="secondary" className="mb-4">Side Hustles</Badge>
        <h1 className="text-balance text-4xl font-bold tracking-tight sm:text-5xl">
          A Beginner's Guide to Flipping Small Websites for a Profit
        </h1>
        <div className="mt-5 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
          <span className="inline-flex items-center gap-1.5"><Calendar className="h-4 w-4" /> June 24, 2026</span>
          <span className="inline-flex items-center gap-1.5"><Clock className="h-4 w-4" /> 9 min read</span>
          <span>By The PassiveHub Team</span>
        </div>

        <div
          className="mt-8 h-56 w-full rounded-2xl sm:h-72"
          style={{ background: "linear-gradient(135deg, oklch(0.93 0.06 160), oklch(0.85 0.08 200))" }}
        />

        <div className="prose-content mt-10 space-y-6 text-[17px] leading-relaxed text-foreground/90">
          <p className="text-lg text-muted-foreground">
            Website flipping is real estate investing for the digital age. You buy an
            under-monetized or under-optimized site, fix what is broken, grow the traffic
            and revenue, and sell it for a multiple of annual profit. In 2026, the market
            for small content sites is more liquid than ever — with marketplaces, brokers,
            and private Facebook groups full of buyers and sellers. Here is how to enter
            the game without losing your shirt.
          </p>

          <h2 className="pt-2 text-2xl font-bold tracking-tight">Where to find sites for sale</h2>
          <p>
            <strong>Flippa</strong> is the largest open marketplace. Listings range from
            $500 starter blogs to six-figure authority sites. Filter by verified traffic
            and revenue, and avoid anything with a traffic spike from a single viral post.
            <strong>Empire Flippers</strong> brokers vetted, larger sites — typically
            $30,000 and up — and handles migration for you. <strong>Motion Invest</strong>
            specializes in smaller content sites under $10,000, making it ideal for first-time
            flippers. Private forums and newsletter deal flows are also worth joining once
            you have a few transactions under your belt.
          </p>

          <h2 className="pt-2 text-2xl font-bold tracking-tight">Due diligence in 30 minutes</h2>
          <p>
            Before you bid, verify three things. First, traffic: use Google Analytics access
            or a read-only report to confirm organic search is the primary source. Second,
            backlinks: run the domain through Ahrefs or Semrush. A healthy site has diverse,
            relevant backlinks — not a single private blog network powering the entire profile.
            Third, revenue proof: ask for screenshots of ad dashboards and affiliate reports.
            If the seller refuses, walk away. Red flags include declining traffic, thin content
            written entirely by AI, and revenue concentrated in a single affiliate program.
          </p>

          <AdSlot label="Ad Placement · 728×90 in-content" className="my-8 h-24" />

          <h2 className="pt-2 text-2xl font-bold tracking-tight">Valuation basics</h2>
          <p>
            Small content sites typically sell for 24–48× monthly profit. A site earning
            $500 per month might list for $12,000–$24,000. The exact multiple depends on
            niche stability, traffic diversity, content quality, and how hands-off the
            operations are. Sites with established teams of writers and virtual assistants
            command higher prices because they are closer to true passive income. Always
            negotiate. Most sellers expect an opening offer 10–20% below asking price.
          </p>

          <h2 className="pt-2 text-2xl font-bold tracking-tight">Quick wins after acquisition</h2>
          <p>
            The fastest way to increase value is to fix low-hanging monetization gaps.
            Upgrade from AdSense to a premium network like Mediavine or Ezoic. Add affiliate
            links to existing top-10 and review posts. Improve page speed — a faster site
            ranks better and earns more from ads because readers scroll further. Then publish
            10–20 new articles targeting underserved long-tail keywords in the same niche.
            These moves can double monthly profit in six months, which at a 36× multiple
            turns a $15,000 site into a $30,000 site.
          </p>

          <h2 className="pt-2 text-2xl font-bold tracking-tight">When to sell vs. hold</h2>
          <p>
            Sell when you have exhausted the easy optimizations and growth is flattening.
            Holding forever is fine if the site produces reliable cash flow, but flipping
            lets you recycle capital into bigger, better assets. Many full-time operators
            follow a simple rhythm: buy, improve, sell at 36×, reinvest 70% into the next
            deal and keep 30% as profit. Repeat four times a year and you are running a
            serious digital investment portfolio.
          </p>

          <h2 className="pt-2 text-2xl font-bold tracking-tight">Start small, think long-term</h2>
          <p>
            Your first flip should cost between $1,000 and $5,000. The goal is not a home
            run — it is to learn the mechanics of transfer, optimization, and sale without
            significant risk. Document every step. After two or three deals, you will have
            a repeatable system and the confidence to scale. Website flipping rewards patience,
            systems, and the willingness to look at a messy site and see what it could become.
          </p>
        </div>

        <Card className="mt-12 border-border/60 bg-muted/40">
          <CardContent className="flex flex-wrap items-center justify-between gap-4 p-6">
            <div>
              <h3 className="text-lg font-semibold">Project your numbers</h3>
              <p className="text-sm text-muted-foreground">
                See what consistent monthly contributions could compound into.
              </p>
            </div>
            <Button asChild className="bg-[color:var(--accent)] text-[color:var(--accent-foreground)] hover:opacity-90">
              <Link to="/" hash="calculator">Open the Calculator</Link>
            </Button>
          </CardContent>
        </Card>

        <p className="mt-8 text-xs text-muted-foreground">
          Educational content only — not financial advice.
        </p>
      </article>
    </div>
  );
}
