import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Calculator,
  TrendingUp,
  Briefcase,
  BookOpen,
  Twitter,
  Github,
  Linkedin,
  Sparkles,
  ArrowRight,
  DollarSign,
  Target,
  Wallet,
} from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PassiveHub — Track Your Journey to Passive Income" },
      { name: "description", content: "Project your passive income, discover proven side hustles, and learn how to build wealth on autopilot." },
      { property: "og:title", content: "PassiveHub — Side Hustle & Passive Income" },
      { property: "og:description", content: "Project your passive income, discover proven side hustles, and build wealth on autopilot." },
    ],
  }),
  component: Index,
});

const hustles = [
  {
    title: "Affiliate Blogging",
    desc: "Earn recurring commissions by recommending products on a niche blog.",
    difficulty: "Medium",
    startup: "$50 – $300",
    monthly: "$500 – $10k",
    icon: BookOpen,
  },
  {
    title: "Digital Products",
    desc: "Sell templates, ebooks, or Notion systems with near-zero marginal cost.",
    difficulty: "Medium",
    startup: "$0 – $200",
    monthly: "$1k – $25k",
    icon: Sparkles,
  },
  {
    title: "Ad Networks",
    desc: "Monetize content sites with Mediavine, Raptive, or AdSense.",
    difficulty: "Easy",
    startup: "$100 – $500",
    monthly: "$200 – $8k",
    icon: TrendingUp,
  },
  {
    title: "Print-on-Demand",
    desc: "Design once, ship forever — apparel & accessories without inventory.",
    difficulty: "Hard",
    startup: "$0 – $150",
    monthly: "$300 – $5k",
    icon: Briefcase,
  },
] as const;

const articles = [
  {
    tag: "Passive Income",
    title: "5 Passive Income Streams Anyone Can Start Online in 2026",
    read: "7 min read",
    href: "/blog/passive-income-streams-2026" as const,
    summary:
      "Affiliate marketing, ad networks, digital products, print-on-demand, and YouTube automation — explained with real numbers and timelines.",
  },
  {
    tag: "Monetization",
    title: "How to Maximize Your Website Earnings Using Alternative Ad Networks",
    read: "8 min read",
    href: "/blog/maximize-website-earnings-ad-networks" as const,
    summary:
      "Stop settling for low RPMs. Learn how to qualify for premium networks, optimize placements, and double your display ad revenue.",
  },
  {
    tag: "Side Hustles",
    title: "A Beginner's Guide to Flipping Small Websites for a Profit",
    read: "9 min read",
    href: "/blog/flipping-websites-beginners-guide" as const,
    summary:
      "A step-by-step playbook for buying, improving, and selling small content websites for 2–4× annual earnings.",
  },
];

function difficultyColor(d: string) {
  if (d === "Easy") return "bg-[color:var(--accent-soft)] text-[color:var(--accent)]";
  if (d === "Medium") return "bg-amber-100 text-amber-800";
  return "bg-rose-100 text-rose-800";
}

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>
        <Hero />
        <ToolSection />
        <BlogSection />
      </main>
      <Footer />
    </div>
  );
}

function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-lg">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <a href="#" className="flex items-center gap-2">
          <div
            className="grid h-9 w-9 place-items-center rounded-xl text-white"
            style={{ background: "var(--gradient-accent)" }}
          >
            <Wallet className="h-5 w-5" />
          </div>
          <span className="text-lg font-bold tracking-tight">PassiveHub</span>
        </a>
        <nav className="hidden items-center gap-8 md:flex">
          <a href="#calculator" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">Calculator</a>
          <a href="#directory" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">Hustle Directory</a>
          <a href="#blog" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">Blog</a>
        </nav>
        <Button className="bg-[color:var(--accent)] text-[color:var(--accent-foreground)] hover:opacity-90">
          Sign Up
        </Button>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section
      className="relative overflow-hidden text-white"
      style={{ background: "var(--gradient-hero)" }}
    >
      <div className="absolute inset-0 opacity-20 [background:radial-gradient(circle_at_20%_20%,white,transparent_40%),radial-gradient(circle_at_80%_60%,oklch(0.62_0.16_160),transparent_45%)]" />
      <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28 lg:py-32">
        <div className="max-w-3xl">
          <Badge className="mb-6 border-white/20 bg-white/10 text-white hover:bg-white/15">
            <Sparkles className="mr-1 h-3 w-3" /> Built for modern earners
          </Badge>
          <h1 className="text-balance text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
            Track Your Journey to{" "}
            <span
              className="bg-clip-text text-transparent"
              style={{ backgroundImage: "var(--gradient-accent)" }}
            >
              Passive Income
            </span>
          </h1>
          <p className="mt-6 max-w-2xl text-pretty text-lg text-white/75">
            Model your portfolio, discover proven side hustles, and learn from operators
            actually building wealth on autopilot. No fluff. Just numbers and playbooks.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button
              size="lg"
              className="bg-[color:var(--accent)] text-[color:var(--accent-foreground)] hover:opacity-90"
              asChild
            >
              <a href="#calculator">
                Try the Calculator <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white/30 bg-white/5 text-white hover:bg-white/10 hover:text-white"
              asChild
            >
              <a href="#directory">Browse Hustles</a>
            </Button>
          </div>
          <div className="mt-10 grid max-w-xl grid-cols-3 gap-6">
            {[
              { v: "$2.4M", l: "Tracked by users" },
              { v: "120+", l: "Hustles indexed" },
              { v: "4.9★", l: "Avg. rating" },
            ].map((s) => (
              <div key={s.l}>
                <div className="text-2xl font-bold">{s.v}</div>
                <div className="text-xs uppercase tracking-wider text-white/60">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function ToolSection() {
  return (
    <section id="calculator" className="border-b border-border bg-muted/40 py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto mb-10 max-w-2xl text-center">
          <Badge variant="outline" className="mb-3">Interactive Tools</Badge>
          <h2 className="text-balance text-3xl font-bold tracking-tight sm:text-4xl">
            Model your money. Pick your hustle.
          </h2>
          <p className="mt-3 text-muted-foreground">
            Switch between the projection calculator and the hustle directory.
          </p>
        </div>

        <Tabs defaultValue="calculator" className="w-full">
          <TabsList className="mx-auto grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="calculator">
              <Calculator className="mr-2 h-4 w-4" /> Calculator
            </TabsTrigger>
            <TabsTrigger value="directory" id="directory">
              <Briefcase className="mr-2 h-4 w-4" /> Directory
            </TabsTrigger>
          </TabsList>

          <TabsContent value="calculator" className="mt-8">
            <ProjectionCalculator />
          </TabsContent>
          <TabsContent value="directory" className="mt-8">
            <HustleDirectory />
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}

function ProjectionCalculator() {
  const [initial, setInitial] = useState(5000);
  const [monthly, setMonthly] = useState(500);
  const [rate, setRate] = useState(8);

  const data = useMemo(() => {
    const r = rate / 100 / 12;
    const out: { year: number; value: number }[] = [];
    let v = initial;
    out.push({ year: 0, value: Math.round(v) });
    for (let m = 1; m <= 120; m++) {
      v = v * (1 + r) + monthly;
      if (m % 12 === 0) out.push({ year: m / 12, value: Math.round(v) });
    }
    return out;
  }, [initial, monthly, rate]);

  const milestone = (y: number) => data.find((d) => d.year === y)?.value ?? 0;
  const fmt = (n: number) => `$${n.toLocaleString("en-US", { maximumFractionDigits: 0 })}`;

  return (
    <Card className="overflow-hidden border-border/60 shadow-[var(--shadow-card)]">
      <div className="grid gap-0 lg:grid-cols-5">
        <CardContent className="space-y-6 border-b border-border/60 bg-card p-6 lg:col-span-2 lg:border-b-0 lg:border-r">
          <div>
            <div className="mb-2 flex items-center justify-between">
              <Label className="flex items-center gap-2 text-sm font-medium">
                <DollarSign className="h-4 w-4 text-[color:var(--accent)]" /> Initial Investment
              </Label>
              <Input
                type="number"
                value={initial}
                onChange={(e) => setInitial(Math.max(0, Number(e.target.value) || 0))}
                className="h-8 w-28 text-right"
              />
            </div>
            <Slider value={[initial]} min={0} max={100000} step={500} onValueChange={(v) => setInitial(v[0])} />
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <Label className="flex items-center gap-2 text-sm font-medium">
                <Wallet className="h-4 w-4 text-[color:var(--accent)]" /> Monthly Contribution
              </Label>
              <Input
                type="number"
                value={monthly}
                onChange={(e) => setMonthly(Math.max(0, Number(e.target.value) || 0))}
                className="h-8 w-28 text-right"
              />
            </div>
            <Slider value={[monthly]} min={0} max={5000} step={50} onValueChange={(v) => setMonthly(v[0])} />
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <Label className="flex items-center gap-2 text-sm font-medium">
                <Target className="h-4 w-4 text-[color:var(--accent)]" /> Expected Annual Return
              </Label>
              <div className="text-sm font-semibold tabular-nums">{rate.toFixed(1)}%</div>
            </div>
            <Slider value={[rate]} min={0} max={20} step={0.5} onValueChange={(v) => setRate(v[0])} />
          </div>

          <div className="grid grid-cols-3 gap-3 pt-2">
            {[1, 5, 10].map((y) => (
              <div
                key={y}
                className="rounded-xl border border-border/60 bg-muted/50 p-3 text-center"
              >
                <div className="text-xs uppercase tracking-wider text-muted-foreground">{y}y</div>
                <div className="mt-1 text-base font-bold text-[color:var(--primary)]">
                  {fmt(milestone(y))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>

        <CardContent className="bg-card p-6 lg:col-span-3">
          <div className="mb-4 flex items-end justify-between">
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">
                Projected balance at year 10
              </div>
              <div
                className="text-3xl font-bold sm:text-4xl"
                style={{ color: "var(--accent)" }}
              >
                {fmt(milestone(10))}
              </div>
            </div>
            <Badge variant="outline" className="hidden sm:inline-flex">
              compounded monthly
            </Badge>
          </div>
          <div className="h-72 w-full sm:h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.62 0.16 160)" stopOpacity={0.6} />
                    <stop offset="100%" stopColor="oklch(0.62 0.16 160)" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="oklch(0.91 0.012 255)" strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="year"
                  tickFormatter={(y) => `${y}y`}
                  tick={{ fontSize: 12, fill: "oklch(0.5 0.03 257)" }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
                  tick={{ fontSize: 12, fill: "oklch(0.5 0.03 257)" }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  formatter={(v: number) => [fmt(v), "Balance"]}
                  labelFormatter={(l) => `Year ${l}`}
                  contentStyle={{
                    borderRadius: 12,
                    border: "1px solid oklch(0.91 0.012 255)",
                    boxShadow: "var(--shadow-card)",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="oklch(0.62 0.16 160)"
                  strokeWidth={3}
                  fill="url(#g)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-3 text-xs text-muted-foreground">
            Estimates are illustrative and do not constitute financial advice.
          </p>
        </CardContent>
      </div>
    </Card>
  );
}

function HustleDirectory() {
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {hustles.map((h) => {
        const Icon = h.icon;
        return (
          <Card
            key={h.title}
            className="group flex flex-col border-border/60 transition-all hover:-translate-y-1 hover:shadow-[var(--shadow-elegant)]"
          >
            <CardContent className="flex flex-1 flex-col gap-4 p-6">
              <div className="flex items-center justify-between">
                <div
                  className="grid h-11 w-11 place-items-center rounded-xl text-white"
                  style={{ background: "var(--gradient-accent)" }}
                >
                  <Icon className="h-5 w-5" />
                </div>
                <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${difficultyColor(h.difficulty)}`}>
                  {h.difficulty}
                </span>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-[color:var(--primary)]">{h.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{h.desc}</p>
              </div>
              <div className="mt-auto space-y-2 border-t border-border/60 pt-4 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Startup cost</span>
                  <span className="font-semibold">{h.startup}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Monthly potential</span>
                  <span className="font-semibold text-[color:var(--accent)]">{h.monthly}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

function AdSlot({ label, className = "" }: { label: string; className?: string }) {
  return (
    <div
      className={`flex items-center justify-center rounded-xl border border-dashed border-border bg-muted/40 text-xs uppercase tracking-widest text-muted-foreground ${className}`}
    >
      {label}
    </div>
  );
}

function BlogSection() {
  return (
    <section id="blog" className="py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div>
            <Badge variant="outline" className="mb-3">From the blog</Badge>
            <h2 className="text-balance text-3xl font-bold tracking-tight sm:text-4xl">
              Playbooks from real operators
            </h2>
          </div>
          <Button variant="ghost" className="text-[color:var(--accent)] hover:text-[color:var(--accent)]">
            View all articles <ArrowRight className="ml-1 h-4 w-4" />
          </Button>
        </div>

        <AdSlot label="Ad Placement · 728×90 leaderboard" className="mb-8 h-24" />

        <div className="grid gap-6 lg:grid-cols-3">
          {articles.map((a, i) => (
            <ArticleCard key={a.title} article={a} index={i} />
          ))}
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-[1fr_300px]">
          <AdSlot label="Ad Placement · in-content native" className="h-32" />
          <AdSlot label="Ad Placement · 300×250" className="h-64" />
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return _Footer();
}

function ArticleCard({
  article,
  index,
}: {
  article: { tag: string; title: string; read: string; href: string | null; summary: string };
  index: number;
}) {
  const card = (
    <Card className="group h-full overflow-hidden border-border/60 transition-all hover:-translate-y-1 hover:shadow-[var(--shadow-card)]">
      <div
        className="h-40 w-full"
        style={{
          background:
            index === 1
              ? "var(--gradient-hero)"
              : "linear-gradient(135deg, oklch(0.93 0.06 160), oklch(0.85 0.08 200))",
        }}
      />
      <CardContent className="p-6">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Badge variant="secondary">{article.tag}</Badge>
          <span>·</span>
          <span>{article.read}</span>
        </div>
        <h3 className="mt-3 text-lg font-semibold leading-snug group-hover:text-[color:var(--accent)]">
          {article.title}
        </h3>
        <p className="mt-2 text-sm text-muted-foreground">
          {article.summary}
        </p>
        <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-[color:var(--accent)]">
          Read article <ArrowRight className="h-3.5 w-3.5" />
        </span>
      </CardContent>
    </Card>
  );

  if (article.href) {
    return (
      <Link to={article.href} className="block">
        {card}
      </Link>
    );
  }
  return <a href="#" className="block">{card}</a>;
}

function _Footer() {
  return (
    <footer className="border-t border-border bg-[color:var(--primary)] text-white/80">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-10 md:grid-cols-4">
          <div>
            <div className="flex items-center gap-2">
              <div
                className="grid h-9 w-9 place-items-center rounded-xl text-white"
                style={{ background: "var(--gradient-accent)" }}
              >
                <Wallet className="h-5 w-5" />
              </div>
              <span className="text-lg font-bold text-white">PassiveHub</span>
            </div>
            <p className="mt-3 max-w-xs text-sm text-white/60">
              Tools and playbooks for builders pursuing financial independence.
            </p>
          </div>
          {[
            { title: "Product", links: ["Calculator", "Hustle Directory", "Blog", "Newsletter"] },
            { title: "Company", links: ["About", "Contact", "Careers", "Press"] },
            { title: "Legal", links: ["Privacy Policy", "Terms of Service", "Affiliate Disclosure", "Cookie Settings"] },
          ].map((c) => (
            <div key={c.title}>
              <div className="mb-3 text-sm font-semibold text-white">{c.title}</div>
              <ul className="space-y-2 text-sm">
                {c.links.map((l) => (
                  <li key={l}>
                    <a href="#" className="text-white/60 transition-colors hover:text-white">{l}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-10 flex flex-col items-start justify-between gap-4 border-t border-white/10 pt-6 sm:flex-row sm:items-center">
          <p className="text-xs text-white/50">
            © {new Date().getFullYear()} PassiveHub. Educational content only — not financial advice.
          </p>
          <div className="flex items-center gap-3">
            {[Twitter, Linkedin, Github].map((Icon, i) => (
              <a
                key={i}
                href="#"
                className="grid h-9 w-9 place-items-center rounded-full bg-white/5 text-white/70 transition-colors hover:bg-white/10 hover:text-white"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
