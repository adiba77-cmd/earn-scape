import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Calendar, Clock, Share2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/blog/passive-income-streams-2026")({
  head: () => ({
    meta: [
      { title: "5 Passive Income Streams Anyone Can Start Online in 2026" },
      {
        name: "description",
        content:
          "A practical guide to five proven passive income streams in 2026: affiliate marketing, ad networks, digital products, print-on-demand, and YouTube automation.",
      },
      { property: "og:title", content: "5 Passive Income Streams Anyone Can Start Online in 2026" },
      {
        property: "og:description",
        content:
          "Affiliate marketing, ad networks, digital products, print-on-demand, and YouTube automation — explained with real numbers.",
      },
    ],
  }),
  component: BlogPost,
});

function AdSlot({ label, className = "" }: { label: string; className?: string }) {
  return (
    <div
      className={`flex items-center justify-center rounded-xl border border-dashed border-border bg-muted/40 text-xs uppercase tracking-widest text-muted-foreground ${className}`}
    >
      {label}
    </div>
  );
}

function BlogPost() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-lg">
        <div className="mx-auto flex h-16 max-w-4xl items-center justify-between px-4 sm:px-6">
          <Link to="/" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Back to PassiveHub
          </Link>
          <Button size="sm" variant="outline" className="gap-2">
            <Share2 className="h-4 w-4" /> Share
          </Button>
        </div>
      </header>

      <article className="mx-auto max-w-3xl px-4 py-12 sm:px-6 sm:py-16">
        <Badge variant="secondary" className="mb-4">Passive Income</Badge>
        <h1 className="text-balance text-4xl font-bold tracking-tight sm:text-5xl">
          5 Passive Income Streams Anyone Can Start Online in 2026
        </h1>
        <div className="mt-5 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
          <span className="inline-flex items-center gap-1.5"><Calendar className="h-4 w-4" /> June 24, 2026</span>
          <span className="inline-flex items-center gap-1.5"><Clock className="h-4 w-4" /> 7 min read</span>
          <span>By The PassiveHub Team</span>
        </div>

        <div
          className="mt-8 h-56 w-full rounded-2xl sm:h-72"
          style={{ background: "linear-gradient(135deg, oklch(0.93 0.06 160), oklch(0.85 0.08 200))" }}
        />

        <div className="prose-content mt-10 space-y-6 text-[17px] leading-relaxed text-foreground/90">
          <p className="text-lg text-muted-foreground">
            Passive income isn't free money — it's leveraged money. You front-load the work,
            and the asset keeps paying. In 2026, the best opportunities sit at the intersection
            of distribution (audience), tooling (AI), and time. Here are five streams that
            anyone with a laptop and a few focused hours per week can realistically start.
          </p>

          <h2 className="pt-2 text-2xl font-bold tracking-tight">1. Affiliate marketing</h2>
          <p>
            Recommend products you actually use and earn a commission when readers buy.
            Pick a tight niche — pickleball gear, home espresso, indie SaaS — and write
            buyer-intent content: comparisons, "best of" lists, and detailed reviews. A
            single well-ranked review can pay for years. Expect 6–12 months before
            meaningful traffic, but margins are near 100% and your only ongoing cost is
            hosting. Programs like Amazon Associates, Impact, and ShareASale make payouts
            trivial.
          </p>

          <h2 className="pt-2 text-2xl font-bold tracking-tight">2. Ad networks</h2>
          <p>
            Once a content site clears 10k–50k monthly sessions, premium ad networks like
            Mediavine, Raptive, and Ezoic become viable. RPMs in 2026 sit between $20 and
            $60 for U.S. traffic depending on niche — personal finance and home improvement
            sit at the top. Stack ads on top of affiliate links and the same article earns
            twice. Best fit for writers who like format-first, evergreen content.
          </p>

          <AdSlot label="Ad Placement · 728×90 in-content" className="my-8 h-24" />

          <h2 className="pt-2 text-2xl font-bold tracking-tight">3. Digital products</h2>
          <p>
            Templates, ebooks, Notion systems, Figma kits, Lightroom presets — anything
            you can sell infinitely without inventory. Platforms like Gumroad, Lemon
            Squeezy, and Stan Store handle payments and delivery, so your only job is
            distribution. The trick is solving one specific, expensive problem for one
            specific audience. A $39 résumé template that saves a designer two hours is
            an easy yes. Margins are 95%+ and you can ship the first version in a weekend.
          </p>

          <h2 className="pt-2 text-2xl font-bold tracking-tight">4. Print-on-demand</h2>
          <p>
            Upload designs to Printful, Printify, or Amazon Merch and they handle printing,
            shipping, and returns. You earn $3–$12 per shirt, mug, or poster sold. The
            winning play in 2026 is niche audience-first: design for specific hobbies,
            inside jokes, or fandoms where buyers self-identify. Pair listings with a
            small TikTok or Pinterest presence and a handful of evergreen designs can
            produce a few hundred dollars a month indefinitely.
          </p>

          <h2 className="pt-2 text-2xl font-bold tracking-tight">5. YouTube automation</h2>
          <p>
            "Faceless" YouTube channels — explainer videos, top-10 lists, documentary-style
            essays — built with a stable workflow of script, voiceover, b-roll, and edit.
            AI tools now collapse production time by 70%, which means a creator can ship
            two videos a week solo. Once a channel hits monetization (1,000 subscribers
            and 4,000 watch hours), AdSense plus sponsorships and affiliate links in the
            description compound quickly. Pick a niche with high CPMs: finance, software
            reviews, real estate.
          </p>

          <h2 className="pt-2 text-2xl font-bold tracking-tight">Where to start</h2>
          <p>
            Pick one. Seriously — one. The biggest mistake new earners make is splitting
            attention across five streams in month one and quitting all of them by month
            four. Choose the stream that overlaps your existing skills, commit to 90 days
            of consistent output, then layer in a second stream only once the first is
            producing. Compound interest works on attention, not just money.
          </p>
        </div>

        <Card className="mt-12 border-border/60 bg-muted/40">
          <CardContent className="flex flex-wrap items-center justify-between gap-4 p-6">
            <div>
              <h3 className="text-lg font-semibold">Project your numbers</h3>
              <p className="text-sm text-muted-foreground">
                See what consistent monthly contributions could compound into.
              </p>
            </div>
            <Button asChild className="bg-[color:var(--accent)] text-[color:var(--accent-foreground)] hover:opacity-90">
              <Link to="/" hash="calculator">Open the Calculator</Link>
            </Button>
          </CardContent>
        </Card>

        <p className="mt-8 text-xs text-muted-foreground">
          Educational content only — not financial advice.
        </p>
      </article>
    </div>
  );
}